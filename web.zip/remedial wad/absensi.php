<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = date('Y-m-d');
    $waktu_masuk = date('H:i:s');

    $stmt = $conn->prepare("INSERT INTO absensi (user_id, tanggal, waktu_masuk) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $user_id, $tanggal, $waktu_masuk);

    $stmt = $conn->prepare("SELECT * FROM absensi WHERE user_id = ? AND tanggal = ?");
    $stmt->bind_param("ss", $user_id, $tanggal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $message = 'Anda sudah melakukan absensi hari ini!';
    } else {
        $stmt = $conn->prepare("INSERT INTO absensi (user_id, tanggal, waktu_masuk) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $user_id, $tanggal, $waktu_masuk);
        if ($stmt->execute()) {
            $message = 'Absensi berhasil dicatat!';
        } else {
            $message = 'Gagal mencatat absensi!';
        }
    }
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafc;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .container {
            background: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 1.5rem;
        }
        p {
            color: #555;
            margin-bottom: 1rem;
        }
        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            background-color: #4caf50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .message {
            color: green;
            margin-top: 1rem;
        }
        .error {
            color: red;
        }
        a {
            color: #4caf50;
            text-decoration: none;
            display: inline-block;
            margin-top: 1rem;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
    <title>Halaman Absensi</title>
</head>
<body>
    <div class="container">
        <h2>Absensi Sekolah</h2>
        <p>Selamat datang, <strong><?php echo htmlspecialchars($user_id); ?></strong>!</p>
        <form method="POST">
            <button class="btn" type="submit">Absensi Masuk</button>
        </form>
        <?php if ($message): ?>
            <p class="message <?php echo ($message === 'Gagal mencatat absensi!') ? 'error' : ''; ?>">
                <?php echo htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
