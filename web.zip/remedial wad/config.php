<?php
$host = 'localhost';
$db = 'sekolah_db';
$user = 'root'; // Sesuaikan dengan user MySQL
$pass = ''; // Sesuaikan dengan password MySQL

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
