<?php
require 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND password = ?");
    $stmt->bind_param("ss", $user_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        session_start();
        $_SESSION['user_id'] = $user_id;
        header('Location: absensi.php');
        exit();
    } else {
        $message = 'ID pengguna atau password salah!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
    body {
        font-family: 'Roboto', 'Times New Roman', Times, serif;
        background-color: #4caf50; /* Sama dengan warna tombol */
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    .login-container {
        background: #ffffff;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
    }
    .login-container h2 {
        text-align: center;
        color: #333;
        margin-bottom: 1.5rem;
    }
    .form-group {
        margin-bottom: 1rem;
    }
    label {
        display: block;
        margin-bottom: 0.5rem;
        color: #555;
    }
    input {
        width: 100%;
        padding: 0.8rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
    }
    input:focus {
        border-color: #4caf50;
        outline: none;
        box-shadow: 0 0 5px rgba(76, 175, 80, 0.3);
    }
    .btn {
        width: 100%;
        padding: 0.8rem;
        background-color: #4caf50;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        margin-top: 1rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .btn:hover {
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 10px 20px rgba(76, 175, 80, 0.3);
    }
    .btn:active {
        transform: translateY(0) scale(1);
        box-shadow: 0 4px 6px rgba(76, 175, 80, 0.2);
    }
    .message {
        color: red;
        text-align: center;
        margin-top: 1rem;
    }
</style>



    <title>Login Absensi</title>
</head>
<body>
    <div class="login-container">
        <h2>Login Absensi</h2>
        <form method="POST">
            <div class="form-group">
                <label for="user_id">ID Pengguna:</label>
                <input type="text" id="user_id" name="user_id" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button class="btn" type="submit">Login</button>
            <?php if ($message): ?>
                <p class="message"><?php echo $message; ?></p>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>
